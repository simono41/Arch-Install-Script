#!/bin/bash

set -x

core=$(grep "cpu cores" /proc/cpuinfo | uniq)
core=${core: -1}

if [ "${core}" -lt "4" ]; then
  cp ~/.Conky/clock_rings_single-core.lua ~/.Conky/clock_rings.lua
else
  cp ~/.Conky/clock_rings_multi-core.lua ~/.Conky/clock_rings.lua
fi

sleep 30 #time (in s) for the DE to start; use ~20 for Gnome or KDE, less for Xfce/LXDE etc
conky -c ~/.Conky/rings & # the main conky with rings
sleep 8 #time for the main conky to start; needed so that the smaller ones draw above not below (probably can be lower, but we still have to wait 5s for the rings to avoid segfaults)
conky -c ~/.Conky/cpu &
sleep 1
conky -c ~/.Conky/mem &
conky -c ~/.Conky/notes &
